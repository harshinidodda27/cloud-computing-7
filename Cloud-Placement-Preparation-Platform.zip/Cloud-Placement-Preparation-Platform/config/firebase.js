const admin = require("firebase-admin");
const path = require("path");

const serviceAccount = require(
    path.join(__dirname, "..", "firebase-service-account.json")
);

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

const firestore = admin.firestore();

console.log("Firebase Firestore connected successfully!");

module.exports = firestore; 